multas = [""]
fichas = [""]

from funciones import*

while True:
    print ("Bienvenido a la automotora Auto Seguro. Seleccione una opción: ")
    opcion = int(input("1. Registrar Vehículo\n2. Buscar por patente\n 3. Imprimir certificado\n 4. Salir\n"))
    if opcion == 1:
        tipo = input ("Ingrese el tipo de vehículo (solo una letra): \n")
        tipoV(tipo)
        patente = input ("Ingrese la patente: \n")
        patenteV(patente)
        marca = input ("Ingrese la marca del vehículo (de 2 a 15 carácteres): \n")
        marcaV(marca)
        precio = 0
        precioV(precio)
        fecha = input ("Ingrese la fecha en formato dd-mm-aaaa: \n")
        fechaV(fecha)
        nombre = input ("Ingrese el nombre del dueño: \n")
        nombreV(nombre)
        multa = input ("Ingrese sus multas en formato monto, causa y fecha. En caso de no tener, escriba 'Sin multas': \n")
        multasV(multa)
        fichas.append([tipo, patente, marca, precio, fecha, nombre, multas])

    if opcion == 2:
        patenteB = input ("Escriba la patente que desea buscar:\n")
        for i in fichas:
            if patenteB == i[0]:
                print (f'''Patente: {i[1]}
                Tipo vehículo: {i[0]}
                Marca: {i[2]}
                Precio: {i[3]}
                Fecha registro: {i[4]} ''')
            else:
                print ("No se ha encontrado la patente. Volviendo al menú principal.")
    if opcion == 3:
        fechaCert = input ("Ingrese la fecha de hoy:\n")
        patenteC = input ("Escriba la patente que desee imprimir el certificado:\n")
        for i in fichas:
            if patenteC == i[0]:
                print (f'''COTIZACION AUTOMOTORA AUTO SEGURO
Se otorga la presente cotización que indica los datos actuales del vehículo a la venta:
Tipo: {i[0]}
Patente: {i[1]}
Marca: {i[2]}
Precio: {i[3]}
Fecha de registro: {i[4]}
Nombre del dueño: {i[5]}
Multas:
{i[6]}
Se otorga esta cotización a la persona que lo solicito para los fines que estime pertinente.
Sin otro particular.
Santiago, {fechaCert}
AUTOMOTORA AUTO SEGURO''')
            else:
                print ("No se ha encontrado la patente. Volviendo al menú principal.")
    if opcion == 4:
        print ("Saliendo. Hasta pronto y gracias por preferirnos.")
        break
multas = [""]

def tipoV(tipito):
    while True:
        try:
            if len(tipito)!=1:
                print ("Por favor solo ingrese un carácter.")
                tipito = input ("Ingrese el tipo de vehículo (solo una letra): \n")
            else:
                break
        except:
            print ("Ha ocurrido una excepción. Intente nuevamente.")

def patenteV(paten):
    while True:
        try:
            if len(paten)!=6:
                print ("Por favor ingrese 6 carácteres.")
                paten = input ("Ingrese la patente: \n")
            else:
                break
        except:
            print ("Ha ocurrido una excepción. Intente nuevamente.")

def marcaV(marc):
    while True:
        try:
            if len(marc)<2 and len(marc)>15:
                print ("Por favor ingrese de 2 a 15 carácteres.")
                marc = input ("Ingrese la marca del vehículo (de 2 a 15 carácteres): \n")
            else:
                break
        except:
            print ("Ha ocurrido una excepción. Intente nuevamente.")

def precioV(precio):
    while True:
        try:
            prec = int(input ("Ingrese el precio del vehículo: \n"))
            if prec < 50000000:
                print ("Por favor ingrese un valor mayor a $5.000.000.")
            else:
                break
        except:
            print ("Ha ocurrido una excepción. Intente nuevamente.")

def fechaV(fec):
    while True:
        try:
            if "-" in fec:
                break
            else:
                print ("Por favor solo ingrese un carácter.")
                fec = input ("Ingrese la fecha en formato dd-mm-aaaa: \n")
        except:
            print ("Ha ocurrido una excepción. Intente nuevamente.")

def nombreV(nom):
    while True:
        try:
            if nom:
                break
            else:
                print ("Por favor no deje el campo en blanco.")
                nom = input ("Ingrese el nombre del dueño: \n")
        except:
            print ("Ha ocurrido una excepción. Intente nuevamente.")

def multasV(mult):
        multas.append([mult])
        while True:
            try:
                opcion2 = int(input("¿Desea añadir otra multa?\n 1. Si\n2. No\n"))
                if opcion2 == 1:
                    multa2 = input ("Ingrese sus multas en formato monto, causa y fecha.\n")
                    multas.append ([multa2])
                if opcion2 == 2:
                    break
                if opcion2>2:
                    print ("No válido. Por favor, ingrese 1 o 2 según corresponda.")
            except:
                print ("Ha ocurrido una excepción. Por favor, intente nuevamente.")